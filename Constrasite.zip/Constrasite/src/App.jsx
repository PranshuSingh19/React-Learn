import { Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Layout from './components/Layout'
import Company from './components/Company'
import About from './components/About-us'
import Our_people from './components/Our-people'
import Testimonials from './components/Testimonials'
import Faq from './components/Faq'
import Pricing from './components/Pricing'
import Contact from './components/Contact'


export function App() {

  return (
    <>
    
    <Routes>
            <Route path='/' element={<Layout/>}>
                  <Route index element={<Home/>} />
                  <Route path='contact' element={<Contact/>} />

                  <Route path='company' element={<Company/>} />
                  <Route path='company/about-us' element={<About/>} />
                  <Route path='company/our-people' element={<Our_people/>} />
                  <Route path='company/testimonials' element={<Testimonials/>} />
                  <Route path='company/faq' element={<Faq/>} />
                  <Route path='company/pricing' element={<Pricing/>} />

            </Route>
        </Routes>
        
    </>
  )
}
