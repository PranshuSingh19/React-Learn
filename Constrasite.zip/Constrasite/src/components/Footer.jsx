import { Link } from "react-router-dom"

const Footer = ()=>{
    return(
        <>
        <footer className="footer bg-overlay" id="footer">
  <div className="footer-main">
    <div className="container">
      <div className="row justify-content-between">
        <div className="col-lg-4 col-md-6 footer-widget footer-about">
          <h3 className="widget-title">About Us</h3>
          <Link to='/'>
          <img
            alt="Constra"
            className="footer-logo"
            loading="lazy"
            src="./assets/images/footer-logo.png"
            width="200px"
          />
          </Link>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor inci done idunt ut labore et dolore magna aliqua.
          </p>
          <div className="footer-social">
            <ul>
              <li>
                <Link
                  aria-label="Facebook"
                  href="https://facebook.com/themefisher">
                  <i className="fab fa-facebook-f" />
                </Link>
              </li>
              <li>
                <Link aria-label="Twitter" href="https://twitter.com/themefisher">
                  <i className="fab fa-twitter" />
                </Link>
              </li>
              <li>
                <Link
                  aria-label="Instagram"
                  href="https://instagram.com/themefisher">
                  <i className="fab fa-instagram" />
                </Link>
              </li>
              <li>
                <Link aria-label="Github" href="https://github.com/themefisher">
                  <i className="fab fa-github" />
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-4 col-md-6 footer-widget mt-5 mt-md-0">
          <h3 className="widget-title">Working Hours</h3>
          <div className="working-hours">
            We work 7 days a week, every day excluding major holidays. Contact
            us if you have an emergency, with our Hotline and Contact form.
            <br />
            <br /> Monday - Friday:{" "}
            <span className="text-right">10:00 - 16:00 </span>
            <br /> Saturday: <span className="text-right">12:00 - 15:00</span>
            <br /> Sunday and holidays:{" "}
            <span className="text-right">09:00 - 12:00</span>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mt-5 mt-lg-0 footer-widget">
          <h3 className="widget-title">Services</h3>
          <ul className="list-arrow">
            <li>
              <Link href="service-single.html">Pre-Construction</Link>
            </li>
            <li>
              <Link href="service-single.html">General Contracting</Link>
            </li>
            <li>
              <Link href="service-single.html">Construction Management</Link>
            </li>
            <li>
              <Link href="service-single.html">Design and Build</Link>
            </li>
            <li>
              <Link href="service-single.html">Self-Perform Construction</Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div className="copyright">
    <div className="container">
      <div className="row align-items-center">
        <div className="col-md-6">
          <div className="copyright-info">
            <span>
              Copyright ©{" "}
              <script
                dangerouslySetInnerHTML={{
                  __html:
                    "                  document.write(new Date().getFullYear())                ",
                }}
              />
              , Designed & Developed by{" "}
              <Link href="#">Themefisher</Link>
            </span>
          </div>
        </div>
        <div className="col-md-6">
          <div className="footer-menu text-center text-md-right">
            <ul className="list-unstyled">
              <li>
                <Link href="about.html">About</Link>
              </li>
              <li>
                <Link href="team.html">Our people</Link>
              </li>
              <li>
                <Link href="faq.html">Faq</Link>
              </li>
              <li>
                <Link href="news-left-sidebar.html">Blog</Link>
              </li>
              <li>
                <Link href="pricing.html">Pricing</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div
        className="back-to-top position-fixed"
        data-offset-top="10"
        data-spy="affix"
        id="back-to-top">
        <button className="btn btn-primary" title="Back to Top">
          <i className="fa fa-angle-double-up" />
        </button>
      </div>
    </div>
  </div>
</footer>
        </>
    )
}
export default Footer