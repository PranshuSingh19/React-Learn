import {Link} from 'react-router-dom'
import Counter from './Counter'

const Home = ()=>{
    return(
        <>

    {/* home slider section      */}
<div className="banner-carousel banner-carousel-2 mb-0">
  <div className="banner-carousel-item" style="background-image:url(./assets/images/slider-main/bg4.jpg)">
    <div className="container">
        <div className="box-slider-content">
          <div className="box-slider-text">
              <h2 className="box-slide-title">17 Years Of Excellence In</h2>
              <h3 className="box-slide-sub-title">Construction Industry</h3>
              <p className="box-slide-description">You have ideas, goals, and dreams. We have a culturally diverse, forward
                thinking team looking for talent like.</p>
              <p>
                <Link to="/services" className="slider btn btn-primary">Our Service</Link>
              </p>
          </div>
        </div>
    </div>
  </div>

  <div className="banner-carousel-item" style="background-image:url(./assets/images/slider-main/bg5.jpg)">
    <div className="slider-content text-left">
        <div className="container">
          <div className="box-slider-content">
              <div className="box-slider-text">
                <h2 className="box-slide-title">When Services Matters</h2>
                <h3 className="box-slide-sub-title">Your Choice is Simple</h3>
                <p className="box-slide-description">You have ideas, goals, and dreams. We have a culturally diverse, forward
                    thinking team looking for talent like.</p>
                <p><Link to="/about" className="slider btn btn-primary" aria-label="about-us">Know Us</Link></p>
              </div>
          </div>
        </div>
    </div>
  </div>
</div>

{/* call section  */}

<section className="call-to-action no-padding">
  <div className="container">
    <div className="action-style-box">
        <div className="row">
          <div className="col-md-8 text-center text-md-left">
              <div className="call-to-action-text">
                <h3 className="action-title">We understand your needs on construction</h3>
              </div>
          </div>
          <div className="col-md-4 text-center text-md-right mt-3 mt-md-0">
              <div className="call-to-action-btn">
                <Link className="btn btn-primary" to="/contact">Request Quote</Link>
              </div>
          </div>
        </div>
    </div>
  </div>
</section>

{/* service section  */}

<section id="ts-features" className="ts-features pb-2">
  <div className="container">
    <div className="row">
        <div className="col-lg-4 col-md-6 mb-5">
          <div className="ts-service-box">
              <div className="ts-service-image-wrapper">
                <img loading="lazy" className="w-100" src="./assets/images/services/service1.jpg" alt="service-image" />
              </div>
              <div className="d-flex">
                <div className="ts-service-box-img">
                    <img loading="lazy" src="./assets/images/icon-image/service-icon1.png" alt="service-icon" />
                </div>
                <div className="ts-service-info">
                    <h3 className="service-box-title"><Link to="service-single.html">Zero Harm Everyday</Link></h3>
                    <p>You have ideas, goals, and dreams. We have a culturally diverse, forward thinking team looking for talent like. Lorem ipsum dolor suscipit.</p>
                    <Link className="learn-more d-inline-block" to="service-single.html" aria-label="service-details"><i className="fa fa-caret-right"></i> Learn more</Link>
                </div>
              </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6 mb-5">
          <div className="ts-service-box">
              <div className="ts-service-image-wrapper">
                <img loading="lazy" className="w-100" src="./assets/images/services/service2.jpg" alt="service-image" />
              </div>
              <div className="d-flex">
                <div className="ts-service-box-img">
                    <img loading="lazy" src="./assets/images/icon-image/service-icon2.png" alt="service-icon" />
                </div>
                <div className="ts-service-info">
                    <h3 className="service-box-title"><Link to="service-single.html">Virtual Construction</Link></h3>
                    <p>You have ideas, goals, and dreams. We have a culturally diverse, forward thinking team looking for talent like. Lorem ipsum dolor suscipit.</p>
                    <Link className="learn-more d-inline-block" to="service-single.html" aria-label="service-details"><i className="fa fa-caret-right"></i> Learn more</Link>
                </div>
              </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6 mb-5">
          <div className="ts-service-box">
              <div className="ts-service-image-wrapper">
                <img loading="lazy" className="w-100" src="./assets/images/services/service3.jpg" alt="service-image" />
              </div>
              <div className="d-flex">
                <div className="ts-service-box-img">
                    <img loading="lazy" src="./assets/images/icon-image/service-icon3.png" alt="service-icon" />
                </div>
                <div className="ts-service-info">
                    <h3 className="service-box-title"><Link to="service-single.html">Build To Last</Link></h3>
                    <p>You have ideas, goals, and dreams. We have a culturally diverse, forward thinking team looking for talent like. Lorem ipsum dolor suscipit.</p>
                    <Link className="learn-more d-inline-block" to="service-single.html" aria-label="service-details"><i className="fa fa-caret-right"></i> Learn more</Link>
                </div>
              </div>
          </div>
        </div>
    </div>
  </div>
</section>

{/* counter sec  */}
    <Counter/>

{/* What We Do sec  */}

<section id="ts-service-area" className="ts-service-area pb-0">
  <div className="container">
    <div className="row text-center">
        <div className="col-12">
          <h2 className="section-title">We Are Specialists In</h2>
          <h3 className="section-sub-title">What We Do</h3>
        </div>
    </div>

    <div className="row">
        <div className="col-lg-4">
          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon1.png" alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Home Construction</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>

          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon2.png" alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Building Remodels</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>

          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon3.png"  alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Interior Design</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>

        </div>

        <div className="col-lg-4 text-center">
          <img loading="lazy" className="img-fluid" src="./assets/images/services/service-center.jpg" alt="service-avater-image" />
        </div>

        <div className="col-lg-4 mt-5 mt-lg-0 mb-4 mb-lg-0">
          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon4.png" alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Exterior Design</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>

          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon5.png" alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Renovation</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>

          <div className="ts-service-box d-flex">
              <div className="ts-service-box-img">
                <img loading="lazy" src="./assets/images/icon-image/service-icon6.png" alt="service-icon" />
              </div>
              <div className="ts-service-box-info">
                <h3 className="service-box-title"><Link to="#">Safety Management</Link></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
              </div>
          </div>
        </div>
    </div>

  </div>
</section>

{/* Projects sec  */}

<section id="project-area" className="project-area solid-bg">
  <div className="container">
    <div className="row text-center">
      <div className="col-lg-12">
        <h2 className="section-title">Work of Excellence</h2>
        <h3 className="section-sub-title">Recent Projects</h3>
      </div>
    </div>

    <div className="row">
      <div className="col-12">
        <div className="shuffle-btn-group">
          <label className="active" for="all">
            <input type="radio" name="shuffle-filter" id="all" value="all" checked="checked" />Show All
          </label>
          <label for="commercial">
            <input type="radio" name="shuffle-filter" id="commercial" value="commercial" />Commercial
          </label>
          <label for="education">
            <input type="radio" name="shuffle-filter" id="education" value="education" />Education
          </label>
          <label for="government">
            <input type="radio" name="shuffle-filter" id="government" value="government" />Government
          </label>
          <label for="infrastructure">
            <input type="radio" name="shuffle-filter" id="infrastructure" value="infrastructure" />Infrastructure
          </label>
          <label for="residential">
            <input type="radio" name="shuffle-filter" id="residential" value="residential" />Residential
          </label>
          <label for="healthcare">
            <input type="radio" name="shuffle-filter" id="healthcare" value="healthcare" />Healthcare
          </label>
        </div>


        <div className="row shuffle-wrapper">
          <div className="col-1 shuffle-sizer"></div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;government&quot;,&quot;healthcare&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project1.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project1.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">Capital Teltway Building</Link>
                  </h3>
                  <p className="project-cat">Commercial, Interiors</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;healthcare&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project2.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project2.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">Ghum Touch Hospital</Link>
                  </h3>
                  <p className="project-cat">Healthcare</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;infrastructure&quot;,&quot;commercial&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project3.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project3.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">TNT East Facility</Link>
                  </h3>
                  <p className="project-cat">Government</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;education&quot;,&quot;infrastructure&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project4.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project4.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">Narriot Headquarters</Link>
                  </h3>
                  <p className="project-cat">Infrastructure</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;infrastructure&quot;,&quot;education&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project5.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project5.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">Kalas Metrorail</Link>
                  </h3>
                  <p className="project-cat">Infrastructure</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 shuffle-item" data-groups="[&quot;residential&quot;]">
            <div className="project-img-container">
              <Link className="gallery-popup" to="./assets/images/projects/project6.jpg" aria-label="project-img">
                <img className="img-fluid" src="./assets/images/projects/project6.jpg" alt="project-img" />
                <span className="gallery-icon"><i className="fa fa-plus"></i></span>
              </Link>
              <div className="project-item-info">
                <div className="project-item-info-content">
                  <h3 className="project-item-title">
                    <Link to="projects-single.html">Ancraft Avenue House</Link>
                  </h3>
                  <p className="project-cat">Residential</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="col-12">
        <div className="general-btn text-center">
          <Link className="btn btn-primary" to="/projects">View All Projects</Link>
        </div>
      </div>

    </div>
  </div>
</section>

<section className="content">
  <div className="container">
    <div className="row">
        <div className="col-lg-6">
          <h3 className="column-title">Testimonials</h3>

          <div id="testimonial-slide" className="testimonial-slide">
              <div className="item">
                <div className="quote-item">
                    <span className="quote-text">
                      Question ran over her cheek When she reached the first hills of the Italic Mountains, she had a last
                      view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the
                      subline of her own road.
                    </span>

                    <div className="quote-item-footer">
                      <img loading="lazy" className="testimonial-thumb" src="./assets/images/clients/testimonial1.png" alt="testimonial" />
                      <div className="quote-item-info">
                          <h3 className="quote-author">Gabriel Denis</h3>
                          <span className="quote-subtext">Chairman, OKT</span>
                      </div>
                    </div>
                </div>
              </div>

              <div className="item">
                <div className="quote-item">
                    <span className="quote-text">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci done idunt ut
                      labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitoa tion ullamco laboris
                      nisi aliquip consequat.
                    </span>

                    <div className="quote-item-footer">
                      <img loading="lazy" className="testimonial-thumb" src="./assets/images/clients/testimonial2.png" alt="testimonial" />
                      <div className="quote-item-info">
                          <h3 className="quote-author">Weldon Cash</h3>
                          <span className="quote-subtext">CFO, First Choice</span>
                      </div>
                    </div>
                </div>
              </div>

              <div className="item">
                <div className="quote-item">
                    <span className="quote-text">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci done idunt ut
                      labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitoa tion ullamco laboris
                      nisi ut commodo consequat.
                    </span>

                    <div className="quote-item-footer">
                      <img loading="lazy" className="testimonial-thumb" src="./assets/images/clients/testimonial3.png" alt="testimonial" />
                      <div className="quote-item-info">
                          <h3 className="quote-author">Minter Puchan</h3>
                          <span className="quote-subtext">Director, AKT</span>
                      </div>
                    </div>
                </div>              </div>

          </div>
        </div>

        <div className="col-lg-6 mt-5 mt-lg-0">

          <h3 className="column-title">Happy Clients</h3>

          <div className="row all-clients">
              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client1.png" alt="clients-logo" /></Link>
                </figure>
              </div>

              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client2.png" alt="clients-logo" /></Link>
                </figure>
              </div>

              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client3.png" alt="clients-logo" /></Link>
                </figure>
              </div>

              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client4.png" alt="clients-logo" /></Link>
                </figure>
              </div>

              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client5.png" alt="clients-logo" /></Link>
                </figure>
              </div>

              <div className="col-sm-4 col-6">
                <figure className="clients-logo">
                    <Link to="#!"><img loading="lazy" className="img-fluid" src="./assets/images/clients/client6.png" alt="clients-logo" /></Link>
                </figure>
              </div>

          </div>

        </div>

    </div>
  </div>
</section>

        </>
    )
}
export default Home