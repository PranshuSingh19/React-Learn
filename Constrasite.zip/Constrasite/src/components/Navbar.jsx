import { Link } from "react-router-dom"

const Navbar = () =>{
    return(
        <>
<div id="top-bar" className="top-bar">
        <div className="container">
          <div className="row">
              <div className="col-lg-8 col-md-8">
                <ul className="top-info text-center text-md-left">
                    <li><i className="fas fa-map-marker-alt"></i> <p className="info-text">9051 Constra Incorporate, USA</p>
                    </li>
                </ul>
              </div>
       
  
              <div className="col-lg-4 col-md-4 top-social text-center text-md-right">
                <ul className="list-unstyled">
                    <li>
                      <Link title="Facebook" to="https://facebbok.com/themefisher.com">
                          <span className="social-icon"><i className="fab fa-facebook-f"></i></span>
                      </Link>
                      <Link title="Twitter" to="https://twitter.com/themefisher.com">
                          <span className="social-icon"><i className="fab fa-twitter"></i></span>
                      </Link>
                      <Link title="Instagram" to="https://instagram.com/themefisher.com">
                          <span className="social-icon"><i className="fab fa-instagram"></i></span>
                      </Link>
                      <Link title="Linkdin" to="https://github.com/themefisher.com">
                          <span className="social-icon"><i className="fab fa-github"></i></span>
                      </Link>
                    </li>
                </ul>
              </div>

          </div>

        </div>
    </div>

<header id="header" className="header-two">
  <div className="site-navigation">
    <div className="container">
        <div className="row">
          <div className="col-lg-12">
              <nav className="navbar navbar-expand-lg navbar-light p-0">
                
                <div className="logo">
                    <Link className="d-block" to="/">
                      <img loading="lazy" src="./assets/images/logo.png" alt="Constra" />
                    </Link>
                </div>

                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                
                <div id="navbar-collapse" className="collapse navbar-collapse">
                    <ul className="nav navbar-nav ml-auto align-items-center">
                      <li className="nav-item dropdown active">
                          <Link to="#" className="nav-link dropdown-toggle" data-toggle="dropdown">Home <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            {/* <li><Link to="index.html">Home One</Link></li> */}
                            <li className="active"><Link to="/">Home</Link></li>
                          </ul>
                      </li>

                      <li className="nav-item dropdown">
                          <Link to="/company" className="nav-link dropdown-toggle" data-toggle="dropdown">Company <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            <li><Link to="/company/about-us">About Us</Link></li>
                            <li><Link to="/company/our-people">Our People</Link></li>
                            <li><Link to="/company/testimonials">Testimonials</Link></li>
                            <li><Link to="/company/faq">Faq</Link></li>
                            <li><Link to="/company/pricing">Pricing</Link></li>
                          </ul>
                      </li>
              
                      <li className="nav-item dropdown">
                          <Link to="#" className="nav-link dropdown-toggle" data-toggle="dropdown">Projects <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            <li><Link to="/projects">Projects All</Link></li>
                            <li><Link to="/project/projects-single">Projects Single</Link></li>
                          </ul>
                      </li>
              
                      <li className="nav-item dropdown">
                          <Link to="#" className="nav-link dropdown-toggle" data-toggle="dropdown">Services <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            <li><Link to="/services">Services All</Link></li>
                            <li><Link to="/service/service-single">Services Single</Link></li>
                          </ul>
                      </li>
              
                      <li className="nav-item dropdown">
                          <Link to="#" className="nav-link dropdown-toggle" data-toggle="dropdown">Features <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            <li><Link to="typography.html">Typography</Link></li>
                            <li><Link to="/404">404</Link></li>
                          </ul>
                      </li>
              
                      <li className="nav-item dropdown">
                          <Link to="#" className="nav-link dropdown-toggle" data-toggle="dropdown">News <i className="fa fa-angle-down"></i></Link>
                          <ul className="dropdown-menu" role="menu">
                            <li><Link to="news-left-sidebar.html">News Left Sidebar</Link></li>
                            <li><Link to="news-right-sidebar.html">News Right Sidebar</Link></li>
                            <li><Link to="news-single.html">News Single</Link></li>
                          </ul>
                      </li>
              
                      <li className="nav-item"><Link className="nav-link" to="/contact">Contact</Link></li>

                      <li className="header-get-a-quote">
                          <Link className="btn btn-primary" to="/contact">Get Free Quote</Link>
                      </li>
                    </ul>
                </div>
              </nav>
          </div>
        </div>
    </div>

  </div>
</header>
        </>
    )
}
export default Navbar