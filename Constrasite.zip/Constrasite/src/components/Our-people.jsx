

const Our_people = ()=>{
    return(
        <>
        <div>
  <div
    className="banner-area"
    id="banner-area"
    style={{
      backgroundImage: "url(./assets/images/banner/banner1.jpg)",
    }}>
    <div className="banner-text">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <div className="banner-heading">
              <h1 className="banner-title">Our Team</h1>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb justify-content-center">
                  <li className="breadcrumb-item">
                    <a href="#">Home</a>
                  </li>
                  <li className="breadcrumb-item">
                    <a href="#">company</a>
                  </li>
                  <li aria-current="page" className="breadcrumb-item active">
                    Our Team
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>{" "}
  <section className="main-container pb-4" id="main-container">
    <div className="container">
      <div className="row text-center">
        <div className="col-lg-12">
          <h3 className="section-sub-title">Our Leaderships</h3>
        </div>
      </div>
      <div className="row justify-content-center">
        <div className="col-lg-3 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team1.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">Nats Stenman</h3>
              <p className="ts-designation">Chief Operating Officer</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-facebook-f" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team2.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">ANGELA LYOUER</h3>
              <p className="ts-designation">Innovation Officer</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-google-plus" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-3 col-md-4 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team3.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">Mark Conter</h3>
              <p className="ts-designation">Safety Officer</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-facebook-f" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-google-plus" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-4 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team4.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">AYESHA STEWART</h3>
              <p className="ts-designation">Finance Officer</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-facebook-f" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-4 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team5.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">Dave Clarkte</h3>
              <p className="ts-designation">Civil Engineer</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-google-plus" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-4 col-sm-6 mb-5">
          <div className="ts-team-wrapper">
            <div className="team-img-wrapper">
              <img
                alt="team-img"
                className="img-fluid"
                loading="lazy"
                src="./assets/images/team/team6.jpg"
              />
            </div>
            <div className="ts-team-content-classic">
              <h3 className="ts-name">Elton Joe</h3>
              <p className="ts-designation">Site Supervisor</p>
              <p className="ts-description">
                Nats Stenman began his career in construction with boots on the
                ground
              </p>
              <div className="team-social-icons">
                <a href="#" target="_blank">
                  <i className="fab fa-facebook-f" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-twitter" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-google-plus" />
                </a>
                <a href="#" target="_blank">
                  <i className="fab fa-linkedin" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
        </>
    )
}
export default Our_people