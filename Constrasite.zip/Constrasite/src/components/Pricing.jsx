

const Pricing = ()=>{
    return(
        <>
        
        </>
    )
}
export default Pricing