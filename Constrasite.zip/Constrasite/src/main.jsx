import { render } from 'preact'
import { App } from './app.jsx'
import { StrictMode } from 'react'
import { BrowserRouter } from 'react-router-dom'

const Root = ()=>(

<StrictMode>
    <BrowserRouter>

     <App />

    </BrowserRouter>
</StrictMode>

);

render ( <Root/>, document.getElementById('app') );