
import './index.css'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './components/Home'
import About from './components/About'
import Practice_area from './components/Practice-area'
import History from './components/History'
import Contact_us from './components/Contact-us'

function App() {

  return (
    <>

    <Routes>
      <Route path='/' element={<Layout />}>
        <Route index element={<Home />} />
        <Route path='/about' element={<About/>} />
        <Route path='/practice-area' element={<Practice_area />} />
        <Route path='/history' element={<History/>} />
        <Route path='/contact-us' element={<Contact_us />} />

      </Route>
    </Routes>

    </>
  )
}

export default App
