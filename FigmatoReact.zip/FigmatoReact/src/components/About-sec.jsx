import {Link} from 'react-router-dom'
export default function About_sec(){
    return(
        <>
<section className="container-fluid about-sec">
        <div className="container">
            <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12">
                    <div className="content">
                        <p className='name'>LYNN M. GALBRAITH-WILSON</p>
                        <h2>Your Attorney</h2>
                        <p>
                        Lynn recognizes that each family is unique. She is dedicated in working with you to achieve the best outcome that is also realistic. She’s hardworking and well respected by her peers. Lynn is known for being a good writer and crafting detailed agreements that are easy to comprehend with the goal of reducing conflict and disputes amongst the family.  Lynn has over <b> 30 years of experience </b> with families in Wisconsin courts. She has experience with various types of family law cases and brings a depth of knowledge to the table. Every case is important to her.
                        </p>
                        <p> <b> Lynn has a proud tradition of professional and community leadership. </b> </p>

                        <button className="inner-button"><span className="material-symbols-outlined">check_circle</span>LEARN MORE</button>
                        <p> <b>Or contact Lynn: <Link to="melto:lynn@galbraith-wilson.com">lynn@galbraith-wilson.com </Link> </b></p>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 sec-img">
                    <img src=".\assets\img\Galbraith-Wilson.jpg" alt="GALBRAITH-WILSON" className='inner-images'/>
                    </div>
            </div>
        </div>
    </section>
        </>
    )
}