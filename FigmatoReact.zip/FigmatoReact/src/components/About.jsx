// import About_sec from "./About-sec"
import Props_about_sec from './Props-about-sec'
import UserCard from './UserCard'

export default function About(){
    return(
        <>
<section className="container-fluid about-banner">
        <div className="container">
            <div className="row banner">
                <div className="col-lg-6 col-md-6 col-sm-12">
                    <div className="content">
                        <p className="name">YOUR ATTORNEY</p>
                        <h1>About</h1>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12">
                    
                    </div>
            </div>
        </div>
    </section>

    {/* <About_sec/> */}
     <Props_about_sec 
         name="LYNN M. GALBRAITH-WILSON"
         title="Your Attorney"
         description=
           "Lynn recognizes that each family is unique. She is dedicated in working with you to achieve the best outcome that is also realistic. She’s hardworking and well respected by her peers. Lynn is known for being a good writer and crafting detailed agreements that are easy to comprehend with the goal of reducing conflict and disputes amongst the family.  Lynn has over 30 years of experience with families in Wisconsin courts. She has experience with various types of family law cases and brings a depth of knowledge to the table. Every case is important to her. Lynn, formerly of Brennan Steil S.C., primarily practices in the area of family law and has handled legal custody, placement, child support, maintenance, other child related financial matters, property division, voluntary paternity acknowledgment cases, paternity and divorce cases, post-divorce motions, post-paternity motions throughout courts in Wisconsin, including complex cases involving business valuation, high income maintenance and support issues, and high conflict family legal disputes. It is her goal in her practice to improve the lives of children and parents of divorce. She received her B.S. degree from the University of Wisconsin Oshkosh (1987) and her J.D. degree from Hamline University School of Law (1993)."
           
         image="./assets/img/Galbraith-Wilson.jpg"
         />


     {/* card section  */}
     <section  className="card-sec">
        <div className="container">
        <div className="content-middle">
          <p className='name'>CONNECTED TO</p>
          <h2>Lynn is a member of:</h2>
        </div>
    
        <div className="row">
            {/* <div className="col"> */}
              <div className="col-md-3">
               <UserCard 
                  name = "Reputation"
                  description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
                  image = ".\assets\img\choose us 1.jpg"
                />
              </div>
              <div className="col-md-3">
               <UserCard 
                  name = "Experience"
                  description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
                  image = ".\assets\img\choose us 2.jpg"
                />
              </div>
              <div className="col-md-3">
               <UserCard 
                  name = "Problem Solving Skills"
                  description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
                  image = ".\assets\img\choose us 3.jpg"
                />
              </div>
              <div className="col-md-3">
               <UserCard 
                  name = "Flexible hours"
                  description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
                  image = ".\assets\img\choose us 4.jpg"
                />
              </div>
            {/* </div> */}
          </div>
        </div>
      </section>

      <section className="history">
      <div className="container">
        <div className="row">
          <div className="col-md-8">
            <h1> Our History</h1>
            <p><b>Decades of Dedication to Legal Excellence and Success</b></p>
          </div>
          <div className="col-md-4 banner-btn">
          <button className="inner-button"><span className="material-symbols-outlined">check_circle</span>LEARN MORE</button>
          </div>
        </div>
      </div>
  </section>
        </>
    )
}