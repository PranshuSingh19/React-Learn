import { Link } from "react-router-dom"
export default function Footer(){
    return(
        <>
        <div className="footer-top">
            <div className="container">
                <div className="row">
                    <div className="col-md-4">
                        <div className="footer-iconbox">
                            <img src=".\assets\img\book.png" alt="Book Now" />
                        <div>
                        <h1>Book Now</h1>
                        <p><b>Schedule Your Consultation Today</b></p>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-7 banner-btn">
                        <button className="inner-button"><span className="material-symbols-outlined">check_circle</span>MAKE AN APPOINTMENT</button>
                    </div>
                </div>
            </div>
        </div>

<footer className="footer text-white">
    <div className="container">
        <div className="row text-center mb-5 mt-3">
            <div className="col">
           <Link to='/'>  <img src="./assets/img/footer-logo.png" alt="footer logo" /> </Link>
           </div>
        </div>
      <div className="row middle-footer">

        {/* Contact Info */}
        <div className="col-md-3 mb-4">
          <h5>Let's Get In Touch</h5>
          <p><i className="bi bi-geo-alt icon"></i>51 S Jackson St. Janesville, WI 53548</p>
          <p><i className="bi bi-telephone icon"></i>608-743-2946</p>
          <p><i className="bi bi-printer icon"></i>608-743-2909</p>
          <p><i className="bi bi-envelope icon"></i><a href="mailto:info@galbraith-wilson.com">info@galbraith-wilson.com</a></p>
        </div>

        {/*  Navigation  */}
        <div className="col-md-2 mb-4">
          <h5>Navigate</h5>
          <p><a href="#">Home</a></p>
          <p><a href="#">About</a></p>
          <p><a href="#">Practice Area</a></p>
          <p><a href="#">History</a></p>
          <p><a href="#">Contact Us</a></p>
        </div>

        {/*  Hours  */}
        <div className="col-md-3 mb-3">
          <h5>Hours</h5>
          <p>Hours: Monday–Friday<br />8:00 am – 5:00 PM</p>
          <p className="bold"><b>*I also offer flexible hours, such as evenings, early mornings, and meetings by appointment only</b></p>
        </div>

        {/* Social & Button */}
        <div className="col-md-4 text-md-end">
          <h5>Socialize With Us</h5>
          <div className="social-icons mb-3">
            <Link to='facebook.com'> <img src="./assets/img/facebook.png" alt="facebook" /> </Link>
            <Link to='linkedin.com'> <img src="./assets/img/linkedin.png" alt="linkedin" /> </Link>
          </div>
          {/* <button className="appointment-btn">Make an Appointment</button> */}
          <button className="action-btn"><span className="material-symbols-outlined">check_circle</span>   MAKE AN APPOINTMENT </button>
        </div>
      </div>

      <hr className="border-secondary" />

      {/*  Notices  */}
      <div className="row mt-4">
        <div className="col disclaimer">
          <h6>Privacy Notice:</h6>
          <p className="text-muted">Any information provided to us through electronic communication is kept confidential within Lynn Galbraith-Wilson Law Office, LLC. It is not sold, leased or otherwise provided to any other outside source. Information about you gathered through technological and electronic methods when accessing our website, including the date and time of your visit, your Internet protocol address, the pages visited and the length of time you spent reviewing them, is kept confidential and used only to evaluate and improve our website for future visitors.</p>
       
          <h6>Legal Notice & Disclaimer:</h6>
          <p className="text-muted">Thank you for visiting our website and your interest in our law office. However your visit does not establish any attorney client relationship between you and our firm or the attorney. In addition you should not send us any information about a specific matter, case or problem that you may have. Any information that may be revealed to us will not be considered confidential or subject to an attorney-client privilege unless we have previously agreed to represent you on the matters related to the information you send. 
            <br/>
          If you would like Lynn, the attorney, to contact you regarding a specific matter, please send ONLY, your name, address and daytime phone number to the information email found on this website. Again do not describe the matter to us over the internet or give us any specific details. Please complete the email form on this website.</p>
        
        </div>
       
      </div>
    </div>

    {/* Bottom Bar */}
    <div className="bottom-bar">
      © 2023 • Lynn Galbraith-Wilson • All Rights Reserved by Pranshu Singh
    </div>
  </footer>
        </>
    )
}