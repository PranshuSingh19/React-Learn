import { Link } from "react-router-dom"
import About_sec from "./About-sec"
import UserCard from "./UserCard"



// Dynamic text change in home page using this method
const reactHeading = [
  "Create by Pranshu Singh",
  "Figma To React",
  "React Development",
];

// random heading
function getRandomInd(max) {
  return Math.floor(Math.random() * (max + 1));
}

export default function Home() {
  const Heading = reactHeading[getRandomInd(2)];

  return (
    <>
 <section className="container-fluid home-banner">
        <div className="container">
            <div className="row banner">
                <div className="col-lg-6 col-md-6 col-sm-12">
                    <div className="content">
                        <p className="name">Your Legal Compass:</p>
                        <h1> <sapn style={{color:'#000', fontWeight:'600'}}>{Heading}</sapn> | Guiding Families Forward</h1>
                        <h3>Assisting you in the next chapter of your life with your family.</h3>

                        <button className="action-btn"><span className="material-symbols-outlined">check_circle</span>   MAKE AN APPOINTMENT </button>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12">
                    
                    </div>
            </div>
        </div>
    </section>

    <div className="container my-4">
    <div className="d-flex justify-content-between flex-wrap info-panel">

      {/* Parking Info  */} 
      <div className="info-box col-md-4">
        <img src="./assets/img/Vector1.png" alt="Car icon" />
        <div className="info-text">
          <small>PARKING AVAILABLE</small>
          <p>in the parking lot or on Jackson Street</p>
        </div>
      </div>

      {/* Office Hours */}
      <div className="info-box col-md-4">
      <img src="./assets/img/Vector2.png" alt="cercle icon" />
        <div className="info-text">
          <small>HOURS: MONDAY-FRIDAY</small>
          <p>8:00 am – 5:00 PM</p>
        </div>
      </div>

      {/* Additional Info  */}
      <div className="info-box col-md-4">
      <img src="./assets/img/Vector3.png" alt="clock icon" />
        <div className="info-note">
          *We also offer flexible hours, such as evenings, early mornings, and meetings by appointment only.
        </div>
      </div>

    </div>
  </div>

{/* About section  */}
 <About_sec/>

 {/* card section  */}
 <section  className="card-sec">
    <div className="container">
    <div className="content-middle">
      <p className='name'>LYNN M. GALBRAITH-WILSON</p>
      <h2>Your Attorney</h2>
    </div>

    <div className="row">
        {/* <div className="col"> */}
          <div className="col-md-3">
          
          {/* These are get by React Propes [name description image written strandred] */}
           <UserCard 
              name = "Reputation"
              description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
              image = ".\assets\img\choose us 1.jpg"
            />
          </div>
          <div className="col-md-3">
          {/* These are get by React Propes [name description image written strandred] */}
           <UserCard 
              name = "Experience"
              description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
              image = ".\assets\img\choose us 2.jpg"
            />
          </div>
          <div className="col-md-3">
          {/* These are get by React Propes [name description image written strandred] */}
           <UserCard 
              name = "Problem Solving Skills"
              description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
              image = ".\assets\img\choose us 3.jpg"
            />
          </div>
          <div className="col-md-3">
          {/* These are get by React Propes [name description image written strandred] */}
           <UserCard 
              name = "Flexible hours"
              description = "With a solid foundation built on years of dedicated legal practice, our firm has garnered a reputation for delivering outstanding results and unmatched client satisfaction. I take pride in our track record of successfully representing my clients, and my commitment to excellence has earned me the trust and respect of both clients and peers in the legal community."
              image = ".\assets\img\choose us 4.jpg"
            />
          </div>
        {/* </div> */}
      </div>
    </div>
  </section>

  {/* Our History sec  */}
  <section className="history">
      <div className="container">
        <div className="row">
          <div className="col-md-8">
            <h1> Our History</h1>
            <p><b>Decades of Dedication to Legal Excellence and Success</b></p>
          </div>
          <div className="col-md-4 banner-btn">
          <button className="inner-button"><span className="material-symbols-outlined">check_circle</span>LEARN MORE</button>
          </div>
        </div>
      </div>
  </section>

  {/* Collaborating Towards section  */}
  <section>
        <div className="container">
            <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-12">
                    <div className="content">
                        <p className='name'>Collaborating Towards Your Legal Triumph.</p>
                        <h2>Working Together For Your Success.</h2>
                        <p>
                        Family law practice is a unique area of law because each case deals with complex human relationships. These relationships continue on long after the case concludes in court. I am a skilled and compassionate litigator who understands and is sensitive to these human factors. <br/> The end of a marriage is often a time of high stress, conflict, and confusion. By listening to my clients, I can tailor a legal strategy that has the greatest chance of success. <br/> I understand you will have plenty of questions throughout your case. I will take the time to promptly and carefully answer your concerns and keep you informed throughout the process. <br/> I understand divorce and family issues strain finances as well as emotions. I attempt to find solutions for my clients in an efficient and economical manner. I operate on the principle that I must earn and retain my clients' trust in every case. <br/> I am here to help you through this stressful and emotional time. With your needs and goals in mind, I will be by your side every step of the way.
                        </p>
                        <p> <b> Lynn has a proud tradition of professional and community leadership. </b> </p>

                       <div className="row">
                        <div className="col-md-6">
                           <button className="inner-button"><span className="material-symbols-outlined">check_circle</span>PRACTICE AREA</button>
                        </div>
                        <div className="col-md-6">
                          <button className="inner-button black-btn"><span className="material-symbols-outlined">check_circle</span> ABOUT ME</button>
                        </div>
                       </div>
                       
                        <p> <b>Or contact Lynn: <Link to="melto:lynn@galbraith-wilson.com">lynn@galbraith-wilson.com </Link> </b></p>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 sec-img">
                   <div className="row">
                    <div className="col-md-6">
                    <img src=".\assets\img\work1img.jpg" alt="Work Image" className='inner-images'/> 
                    <img src=".\assets\img\work2img.jpg" alt="Work Image" className='inner-images' style={{paddingTop:'10px', paddingBottom:'10px'}}/>
                    </div>
                    <div className="col-md-6">
                    <img src=".\assets\img\work3img.jpg" alt="Work Image" className='inner-images'/>
                    </div>
                   </div>
                    </div>
            </div>
        </div>
    </section>
        </>
    )
}