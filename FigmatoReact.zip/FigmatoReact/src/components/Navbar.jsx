import { Link } from "react-router-dom"


export default function Navbar(){
    return(
        <>
          
  {/* Top bar */}
  <div className="top-bar d-flex justify-content-between align-items-center">
    <div>Lynn Galbraith-Wilson Law Office, LLC | Family & Divorce Lawyer</div>
    <div>
      <i className="bi bi-envelope"></i> info@galbraith-wilson.com &nbsp;
      <i className="bi bi-geo-alt"></i> 51 S Jackson St. Janesville, WI 53548
    </div>
  </div>

  {/* Navbar  */}
  <nav className="navbar navbar-expand-lg bg-white border-bottom">
    <div className="container-fluid">
      <Link className="navbar-brand logo" to="/"><img src="./assets/img/logo.svg" alt="site logo" />
      </Link>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span className="navbar-toggler-icon"></span>
      </button>
      
      <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul className="navbar-nav me-3">
      <li className="nav-item">
            <Link className="nav-link active" to="/">HOME</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/about">ABOUT</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/practice-area">PRACTICE AREA</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/history">HISTORY</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/contact-us">CONTACT US</Link>
          </li>
          
        {/* <li className="nav-item">
          <Link className={({ isActive }) => `nav-link${isActive ? " active" : ""}`} to="/">HOME</Link>
        </li>
        <li className="nav-item">
          <Link className={({ isActive }) => `nav-link${isActive ? " active" : ""}`} to="/about">ABOUT</Link>
        </li>
        <li className="nav-item">
          <Link className={({ isActive }) => `nav-link${isActive ? " active" : ""}`} to="/practice-area">PRACTICE AREA</Link>
        </li>
        <li className="nav-item">
          <Link className={({ isActive }) => `nav-link${isActive ? " active" : ""}`} to="/history">HISTORY</Link>
        </li>
        <li className="nav-item">
          <Link className={({ isActive }) => `nav-link${isActive ? " active" : ""}`} to="/contact-us">CONTACT US</Link>
        </li> */}
      </ul>
        <Link to="tel:6087432946" className="btn btn-call d-flex align-items-center">
          <i className="bi bi-telephone me-2"></i> 608-743-2946
        </Link>
      </div>
    </div>
  </nav>
        </>
    )
}