// import About_sec from "./About-sec";
import PracticeCard from "./PracticeCard"
import Props_about_sec from "./Props-about-sec"

export default function Practice_area(){
    return(
        <>
        
        <section className="container-fluid practice-banner">
        <div className="container">
            <div className="row banner">
                <div className="col-lg-6 col-md-6 col-sm-12">
                    <div className="content">
                        <p className="name">FAMILY LAW</p>
                        <h1>Practice Area</h1>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12">
                    
                    </div>
            </div>
        </div>
    </section>

     <Props_about_sec 
     name="Compassionate Representation for Complex Matters"
     title="Lynn's Family Law Practice"
     description=
       "In the realm of family law, each case delves into intricate human relationships that endure well beyond the courtroom's gavel. Lynn's exceptional legal practice focuses on addressing these complexities. <br/> The end of a marriage often ushers in a period of heightened stress, conflict, and confusion. Lynn excels at crafting legal strategies tailored to individual cases, maximizing the chance of success. Throughout your journey, you're bound to have questions. Rest assured, Lynn is dedicated to offering prompt, careful responses and ensuring you remain well-informed throughout the legal process. Lynn acknowledges that divorce and family issues can strain both finances and emotions. Her approach is both efficient and economical, operating on the principle of earning and retaining her clients' trust in every case. During this challenging and emotional period, Lynn is here to support you. With your unique needs and objectives in mind, she'll stand by your side at every turn."

     image="./assets/img/Attorney-Lynn.jpg"
     />

    <section className="container-fluit our-family">
        <div className="container">
            <div className="row banner">
                <div className="col">
                    <p className="name">Our Family Law Practice Areas</p>
                    <h2>Comprehensive Legal Services Tailored to Your Needs</h2>
                </div>
            </div>
        </div>
    </section>  
<section style={{backgroundColor: '#F9F9F9'}}>
    <div className="container">
        <div className="row">
          <div className="col-md-4">
            <PracticeCard
                name='Divorce'
                descriptionList={[
                    "Property Division",
                    "Financial and Business Matters in Divorce",
                    "Alimony/Spousal Maintenance/Spousal Support"
                ]}
                img="./assets/img/practicecrd1.jpg"
            />
          </div>    
          <div className="col-md-4">
          <PracticeCard
                name='Child Custody and Support'
                descriptionList={[
                    "Child Custody and Placement",
                    "Child Support",
                    "Post-Judgment Disputes and Modifications"
                ]}
                img="./assets/img/practicecrd2.jpg"
            />
          </div>    
          <div className="col-md-4">
          <PracticeCard
                name='Family Matters'
                descriptionList={[
                    "Adoption",
                    "Paternity",
                    "Domestic Partnerships and Non-Traditional Families"
                ]}
                img="./assets/img/practicecrd3.jpg"
            />
          </div>    
        </div>   

        <div className="row">
                    <div className="col-md-6">
                    <PracticeCard
                name='Legal Proceedings'
                descriptionList={[
                    "Protection Orders and Restraining Orders",
                    "Guardianships",
                    "Termination of Parental Rights",
                    "Grandparent Rights",
                    "Domestic Abuse"
                ]}
                img="./assets/img/practicecrd4.jpg"
            />
                    </div>
                    <div className="col-md-6">
                    <PracticeCard
                name='Alternative Solutions'
                descriptionList={[
                    "Collaborative Divorce",
                    "Mediation/Arbitration/Alternative Dispute Resolution"
                ]}
                img="./assets/img/practicecrd5.jpg"
            />
             <PracticeCard
                name='Other Services'
                descriptionList={[
                    "Prenuptial and Postnuptial Agreements",
                    "Relocation",
                    "Annulments"
                ]}
                img="./assets/img/practicecrd6.jpg"
            />

                    </div>
                   </div>    
    </div> 
</section> 
        </>
    )
}