import React from "react"


// This is  Our Family Law Practice Areas
export default function PracticeCard({name, descriptionList, img}){
    return(
        <>
        <div style={{
        textAlign: "left",
        borderBottom: '10px solid #c04b26',
        borderLeft: '0',
        borderRight: '0',
        borderTop: '0',
        borderRadius: '20px',
        margin: '10px',
        // padding: '30px',
        // width: '313px',
        backgroundColor: '#fff',
        boxShadow: 'rgb(210 210 210 / 20%) 0px 4px 8px',
      }}>
        <img src={img} alt={name} style={{width:"100%", borderRadius:'10px 10px 0px 0px'}} />
        
        <div className="card-contant">
        <h4 style={{
            padding: '10px 0px',
            fontWeight: '700',
        }}>{name}</h4>
        {/* <p>{description}</p> */}

        {/* Description list with icon */}
        <ul style={{ paddingLeft: 0, listStyle: 'none' }}>
            {descriptionList.map((item, index) => (
            <li key={index} style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '10px' }}>
                <span className="material-symbols-outlined" style={{ color: '#c04b26', marginRight: '8px' }}>
                check_circle
                </span>
                <span>{item}</span>
            </li>
            ))}
        </ul>
        </div>

    </div>

        </>
    )
}