import React from 'react';
// import { Link } from 'react-router-dom';

export default function Props_about_sec({ name, title, description, image }) {
  return (
    <>
      <section className="container-fluid about-sec">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 col-md-6 col-sm-12">
              <div className="content">
                <p className='name'>{name}</p>
                <h2>{title}</h2>
                <p>{description}</p>
              </div>
            </div>
            <div className="col-lg-6 col-md-6 col-sm-12 sec-img">
              <img src={image} alt={name} className='inner-images' />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
