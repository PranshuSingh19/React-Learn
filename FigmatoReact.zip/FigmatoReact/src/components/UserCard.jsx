import React from "react"
export default function UserCard({name, description, image}){
    return(
        <>
        <div style={{
        textAlign: "left",
        borderTop: '10px solid #c04b26',
        borderLeft: '0',
        borderRight: '0',
        borderBottom: '0',
        borderRadius: '20px',
        margin: '10px',
        padding: '30px',
        width: '313px',
        backgroundColor: '#fff',
        boxShadow: 'rgb(210 210 210 / 20%) 0px 4px 8px',
      }}>
<img src={image} alt={name} style={{width:"125px"}} />
<h4 style={{
    padding: '10px 0px',
    fontWeight: '700',
}}>{name}</h4>
<p>{description}</p>

    </div>

        </>
    )
}