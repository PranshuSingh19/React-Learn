import About from "./pages/About"
import ActionSec from "./pages/Action-sec"
import Banner from "./pages/Banner"
import Clients from "./pages/Clients"
import Contact from "./pages/Contact"
import Feature from "./pages/Feature"
import Footer from "./pages/Footer"
import Navbar from "./pages/Navbar"
import Portfolio from "./pages/Portfolio"
import Service from "./pages/Service"
import Stats from "./pages/Stats"
import Team from "./pages/Team"
import Testimonial from "./pages/Testimonial"


function App() {

  return (
    <>
<Navbar />
<Banner />
<About />
<Clients />
<Feature />
<Service />
<ActionSec/>
<Portfolio/>
<Stats/>
<Testimonial/>
<Team/>
<Contact/>
<Footer/>
    </>
  )
}

export default App
