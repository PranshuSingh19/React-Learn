export default function Clients(){

    return(
        <>
<section id="clients" classname="clients section">
  <div classname="container" data-aos="fade-up" data-aos-delay={100}>
    <div classname="swiper init-swiper">
      <div classname="swiper-wrapper align-items-center">
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-1.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-2.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-3.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-4.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-5.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-6.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-7.png"
            classname="img-fluid"
            alt=""
          />
        </div>
        <div classname="swiper-slide">
          <img
            src="./src/assets/img/clients/client-8.png"
            classname="img-fluid"
            alt=""
          />
        </div>
      </div>
      <div className="swiper-pagination" />
    </div>
  </div>
</section>

        </>
    )
}