import './App.css'
import Navbar from './componant/Navbar'
import Banner from './componant/Banner'
import Footer from './componant/Footer'
import Service from './componant/Service'
import Action from './componant/Action'
import About from './componant/About'
import Counter from './componant/Counter'
import Feature from './componant/Feature'
import Services from './componant/Services-sec'
import Tabs from './componant/Tabs'
import Testimonial from './componant/Testimonial'
import Gallery from './componant/Gallery'
import Pricing from './componant/Pricing'
import Faq from './componant/Faq'
import Contact from './componant/Contact'

function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
   <Navbar/>
  <Banner/>
  <Service/>
  <Action/>
  <About/>
  <Counter/>
  <Feature/>
  <Services/>
  <Tabs/>
  <Testimonial/>
  <Gallery/>
  <Pricing/>
  <Faq/>
  <Contact/>

  <Footer/>
    </>
  )
}

export default App
