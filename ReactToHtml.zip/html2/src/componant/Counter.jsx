export default function Counter(){
    return(
        <>
<section id="stats" className="stats section">

<div className="container" data-aos="fade-up" data-aos-delay="100">

  <div className="row gy-4">

    <div className="col-lg-3 col-md-6">
      <div className="stats-item d-flex align-items-center w-100 h-100">
        <i className="fas fa-user-md flex-shrink-0"></i>
        <div>
          <span data-purecounter-start="0" data-purecounter-end="25" data-purecounter-duration="1" className="purecounter"></span>
          <p>Doctors</p>
        </div>
      </div>
    </div>

    <div className="col-lg-3 col-md-6">
      <div className="stats-item d-flex align-items-center w-100 h-100">
        <i className="far fa-hospital flex-shrink-0"></i>
        <div>
          <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1" className="purecounter"></span>
          <p>Departments</p>
        </div>
      </div>
    </div>

    <div className="col-lg-3 col-md-6">
      <div className="stats-item d-flex align-items-center w-100 h-100">
        <i className="fas fa-flask flex-shrink-0"></i>
        <div>
          <span data-purecounter-start="0" data-purecounter-end="8" data-purecounter-duration="1" className="purecounter"></span>
          <p>Research Labs</p>
        </div>
      </div>
    </div>

    <div className="col-lg-3 col-md-6">
      <div className="stats-item d-flex align-items-center w-100 h-100">
        <i className="fas fa-award flex-shrink-0"></i>
        <div>
          <span data-purecounter-start="0" data-purecounter-end="150" data-purecounter-duration="1" className="purecounter"></span>
          <p>Awards</p>
        </div>
      </div>
    </div>

  </div>

</div>

</section>
        </>
    )
}