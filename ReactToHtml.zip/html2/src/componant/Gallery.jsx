export default function Gallery(){
    return(
        <>
<section className="gallery section py-5" id="gallery">
  <div className="container">
    <div className="text-center mb-4" data-aos="fade-up">
      <h2 className="fw-bold">Gallery</h2>
      <p className="text-muted">
        Necessitatibus eius consequatur ex aliquid fuga eum quidem sint
        consectetur velit
      </p>
    </div>

    <div className="container">
	<div className="row">
		<div className="Carousel" data-items="1,3,5,6" data-slide="1" id="Carousel"  data-interval="1000">
            <div className="MultiCarousel-inner">
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
                <div className="item">
                    <div className="pad15">
                        <p className="lead">Multi Item Carousel</p>
                        <p>₹ 1</p>
                        <p>₹ 6000</p>
                        <p>50% off</p>
                    </div>
                </div>
            </div>
            <button className="btn btn-primary leftLst">Prev</button>
            <button className="btn btn-primary rightLst">Next</button>
        </div>
	</div>
	<div className="row">
	    <div className="col-md-12 text-center">
	        <br/><br/><br/>
	        <hr/>
	        <p>Settings</p>
	        <p>Change data items for xs,sm,md and lg display items respectively. Ex:data-items="1,3,5,6"</p>
	        <p>Change data slide for slides per click Ex:data-slide="1"</p>
	    </div>
	</div>
</div>
  </div>
</section>

        </>
    )
}