export default function Testimonial(){
    return(
        <>
<section
  className="testimonials section"
  id="testimonials"
>
  <div
    className="container section-title"
    data-aos="fade-up"
  >
    <h2>
      Testimonials
    </h2>
    <p>
      Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit
    </p>
  </div>
  <div
    className="container"
    data-aos="fade-up"
    data-aos-delay="100"
  >
    <div
      className="swiper init-swiper"
      data-breakpoints="{ &quot;320&quot;: { &quot;slidesPerView&quot;: 1, &quot;spaceBetween&quot;: 40 }, &quot;1200&quot;: { &quot;slidesPerView&quot;: 3, &quot;spaceBetween&quot;: 40 } }"
      data-delay="5000"
      data-speed="600"
    >
      <script
        className="swiper-config"
        dangerouslySetInnerHTML={{
          __html: '      {        "loop": true,        "speed": 600,        "autoplay": {          "delay": 5000        },        "slidesPerView": "auto",        "pagination": {          "el": ".swiper-pagination",          "type": "bullets",          "clickable": true        },        "breakpoints": {          "320": {            "slidesPerView": 1,            "spaceBetween": 40          },          "1200": {            "slidesPerView": 3,            "spaceBetween": 20          }        }      }    '
        }}
        type="application/json"
      />
      <div className="swiper-wrapper">
        <div className="swiper-slide">
          <div className="testimonial-item">
            <p>
              <i className=" bi bi-quote quote-icon-left" />
              <span>
                Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
              </span>
              <i className="bi bi-quote quote-icon-right" />
            </p>
            <img
              alt=""
              className="testimonial-img"
              src="./src/assets/img/testimonials/testimonials-1.jpg"
            />
            <h3>
              Saul Goodman
            </h3>
            <h4>
              Ceo & Founder
            </h4>
          </div>
        </div>
        <div className="swiper-slide">
          <div className="testimonial-item">
            <p>
              <i className="bi bi-quote quote-icon-left" />
              <span>
                Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
              </span>
              <i className="bi bi-quote quote-icon-right" />
            </p>
            <img
              alt=""
              className="testimonial-img"
              src="./src/assets/img/testimonials/testimonials-2.jpg"
            />
            <h3>
              Sara Wilsson
            </h3>
            <h4>
              Designer
            </h4>
          </div>
        </div>
        <div className="swiper-slide">
          <div className="testimonial-item">
            <p>
              <i className="bi bi-quote quote-icon-left" />
              <span>
                Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
              </span>
              <i className="bi bi-quote quote-icon-right" />
            </p>
            <img
              alt=""
              className="testimonial-img"
              src="./src/assets/img/testimonials/testimonials-3.jpg"
            />
            <h3>
              Jena Karlis
            </h3>
            <h4>
              Store Owner
            </h4>
          </div>
        </div>
        <div className="swiper-slide">
          <div className="testimonial-item">
            <p>
              <i className="bi bi-quote quote-icon-left" />
              <span>
                Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
              </span>
              <i className="bi bi-quote quote-icon-right" />
            </p>
            <img
              alt=""
              className="testimonial-img"
              src="./src/assets/img/testimonials/testimonials-4.jpg"
            />
            <h3>
              Matt Brandon
            </h3>
            <h4>
              Freelancer
            </h4>
          </div>
        </div>
        <div className="swiper-slide">
          <div className="testimonial-item">
            <p>
              <i className="bi bi-quote quote-icon-left" />
              <span>
                Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
              </span>
              <i className="bi bi-quote quote-icon-right" />
            </p>
            <img
              alt=""
              className="testimonial-img"
              src="./src/assets/img/testimonials/testimonials-5.jpg"
            />
            <h3>
              John Larson
            </h3>
            <h4>
              Entrepreneur
            </h4>
          </div>
        </div>
      </div>
      <div className="swiper-pagination" />
    </div>
  </div>
</section>
        </>
    )
}