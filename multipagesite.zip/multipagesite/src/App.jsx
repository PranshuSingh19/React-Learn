import { Route, Routes } from "react-router-dom"
import Home from "./camponent/Home"
import OurCars from "./camponent/OurCars"
import About from "./camponent/About"
import Contact from "./camponent/Contact"
import Layout from "./camponent/Layout"

function App() {

  return (
    <>

  <Routes>
 
    {/* Layout is the nested route components */}
    <Route path="/" element={<Layout/>} >
      {/* All pages routes  */}
      <Route index element={<Home/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/ourcar" element={<OurCars />}/>
      <Route path="/contact" element={<Contact/>}/>

      </Route>

  </Routes>
    </>
  )
}

export default App
