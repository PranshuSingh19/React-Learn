import { useState } from "react";




function Hidecontent(){

    const  [ showmore, showless ] = useState();

    const toggleContent=()=>{
        showless(!showmore);
    }

    return(

        <>
        <p>

        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis omnis, impedit laudantium quidem debitis fuga maxime, voluptate placeat libero dolore dolorum sint magnam doloribus similique eos consectetur? Dicta explicabo molestiae illo voluptatibus commodi, architecto, sequi, voluptas rem ducimus quam aspernatur. Harum quibusdam quo ea fugiat ad eius, doloremque porro eligendi, laboriosam amet neque delectus nam totam! Et harum laboriosam ratione fuga cupiditate, adipisci facilis! Deserunt cupiditate vero sit itaque, architecto magni obcaecati voluptas eligendi illum. Repellendus voluptate nemo architecto esse quis corrupti ducimus ratione qui ipsa facere. Corrupti magnam illum non ad veniam accusantium fugiat, repellendus beatae iste vitae, iusto eius ducimus.
        
        {showmore && (
        <div>
         Modi tenetur ducimus ipsum sint praesentium deserunt suscipit voluptatum voluptas animi optio, quos quisquam vel nesciunt fugiat, dolores pariatur tempore! Sunt, id eligendi impedit facilis nostrum dolorum error perferendis tempore expedita enim at quibusdam accusantium porro? Sit impedit voluptates dicta repudiandae ea. Cum alias nisi labore recusandae harum, quis, porro non, quidem ab quae id excepturi iste. Alias voluptatibus dolor incidunt expedita tempora blanditiis laboriosam natus quae iste necessitatibus eveniet fugit quidem eius consequuntur voluptate aliquam fuga officia quia ipsa ipsum dolore nisi, itaque nulla. Magnam obcaecati perspiciatis ab blanditiis officiis provident odit esse facilis, quisquam culpa inventore.
         </div>
        )}
         <button type='button' onClick={toggleContent}   className='bg-red-500 px-3 py-1 rounded cursor-pointer mt-5 mx-2 my-10'> {showmore ? 'ShowLess' : 'ShowMore'} </button>
        </p>
        </>
    )
}
export default Hidecontent;